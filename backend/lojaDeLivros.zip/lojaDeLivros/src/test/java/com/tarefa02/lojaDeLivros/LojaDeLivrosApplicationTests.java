package com.tarefa02.lojaDeLivros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaDeLivrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
